﻿import { Component } from '@angular/core';

@Component({
    selector: 'ic-index',
    templateUrl: '/templates/v0102/admins/index.tpl.html'
})
export class IndexComponent { }
