
    export class LoginViewModel { 
        public Email: string;
        public Password: string;
        public RememberMe: boolean;
        public IsOk: boolean;
        public errorMessage: string;
        public mainRole: string;
    }