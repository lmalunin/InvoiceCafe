
    export class DebtorViewModel { 
    }