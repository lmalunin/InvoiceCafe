
    export class EDSLocalSignatureViewModel { 
        public message: string;
        public detached: boolean;
        public certificate: string;
        public fileId: string;
        public Id: string;
        public signature: string;
    }