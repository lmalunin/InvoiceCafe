
    export class ClientDocumentViewModel { 
        public Id: string;
        public Title: string;
        public PathKey: string;
        public Description: string;
        public FileType: number;
    }