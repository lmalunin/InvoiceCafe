﻿var ts = require('gulp-typescript');
var gulp = require('gulp');
var clean = require('gulp-clean');

var destPath = './wwwroot/libs/';

// Delete the dist directory
gulp.task('clean', function () {
    return gulp.src(destPath)
        .pipe(clean());
});

gulp.task("scriptsNStyles", () => {
    gulp.src([
            'core-js/client/**',
            'systemjs/dist/system.src.js',
            'reflect-metadata/**',
            'rxjs/**',
            'zone.js/dist/**',
            '@angular/**',
            'ng2-translate/**',
            //'@vaadin/**',

            'jquery/dist/jquery.*js',
            'bootstrap/dist/**'
    ], {
        cwd: "node_modules/**"
    })
        .pipe(gulp.dest("./wwwroot/libs"));
});

gulp.task("resources", () => {
    gulp.src([
        'resources/**'
    ], {
        cwd: "scripts/**"
    })
    .pipe(gulp.dest("./wwwroot/app"));
});

var tsProject = ts.createProject('scripts/tsconfig.json');
gulp.task('ts', function (done) {
    //var tsResult = tsProject.src()
    var tsResult = gulp.src([
            "Scripts/**/*.ts"
    ])
        .pipe(ts(tsProject), undefined, ts.reporter.fullReporter());
    return tsResult.js.pipe(gulp.dest('./wwwroot/app/'));
});

gulp.task('watch', ['watch.ts']);

gulp.task('watch.ts', ['ts', 'resources'], function () {
    return gulp.watch('scripts/**/*.ts', ['ts']);
});

gulp.task('default', ['scriptsNStyles', 'resources', 'watch']);