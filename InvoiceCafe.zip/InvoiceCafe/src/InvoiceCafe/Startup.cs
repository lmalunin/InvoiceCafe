﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using InvoiceCafe.Data;
using InvoiceCafe.Models;
using InvoiceCafe.Services;
using Microsoft.AspNetCore.Http;
using System.Globalization;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Http.Features;
using Serilog.Events;
using Serilog;

namespace InvoiceCafe
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true);

            if (env.IsDevelopment())
            {
                // For more details on using the user secret store see http://go.microsoft.com/fwlink/?LinkID=532709
                builder.AddUserSecrets();
            }

            builder.AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        public IConfigurationRoot Configuration { get; }

        // культура, установленная по умолчанию (ru-RU) не работает; во View всегда en-US. Этот фильтр добавлен для решения проблемы, согласно http://stackoverflow.com/questions/38840183/asp-net-core-1-0-rtm-localization-not-working
        public class CultureSettingResourceFilter : IResourceFilter
        {
            public void OnResourceExecuted(ResourceExecutedContext context)
            { }

            public void OnResourceExecuting(ResourceExecutingContext context)
            {
                var request = context.HttpContext.Request;
                var response = context.HttpContext.Response;

                //var culture = httpContext.GetRouteValue("your-culture-key-name")?.ToString();
                // set your culture here
                //var defaultCulture = CultureInfo.GetCultureInfo("en-US");
                var defaultCulture = CultureInfo.GetCultureInfo("ru-RU");
                CultureInfo.CurrentCulture = defaultCulture;
                CultureInfo.CurrentUICulture = defaultCulture;
            }
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // Add framework services.
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            services.AddIdentity<ApplicationUser, InvoiceCafeRole>(o =>
            {
                o.Password.RequireDigit = false;
                o.Password.RequireLowercase = false;
                o.Password.RequireNonAlphanumeric = false;
                o.Password.RequireUppercase = false;
                o.Password.RequiredLength = 8;
            })
                .AddEntityFrameworkStores<ApplicationDbContext, Guid>()
                .AddDefaultTokenProviders()
                .AddUserStore<UserStore<ApplicationUser, InvoiceCafeRole, ApplicationDbContext, Guid>>()
                .AddRoleStore<RoleStore<InvoiceCafeRole, ApplicationDbContext, Guid>>();

            services.AddLocalization(options => options.ResourcesPath = "Resources");

            services.AddMvc(options =>
            {
                options.Filters.Add(new CultureSettingResourceFilter());
            })
            .AddJsonOptions(options =>
            {
                options.SerializerSettings.ContractResolver = new Newtonsoft.Json.Serialization.DefaultContractResolver();
            })
            .AddViewLocalization(LanguageViewLocationExpanderFormat.Suffix)
            .AddDataAnnotationsLocalization();

            //services.AddAuthorization(options =>
            //{
            //    options.AddPolicy("Suppliers", policy => policy.RequireClaim("Supplier"));
            //    options.AddPolicy("Signed", policy => policy.RequireClaim("Signed"));
            //});

            services.Configure<FormOptions>(options =>
            {
                options.MultipartBodyLengthLimit = 50000000;
            });

            // Add application services.
            services.AddSingleton<IConfiguration>(sp => { return Configuration; });
            services.AddTransient<IEmailSender, AuthMessageSender>();
            services.AddTransient<ISmsSender, AuthMessageSender>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
                app.UseBrowserLink();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();

            app.UseIdentity();

            app.UseCookieAuthentication(new CookieAuthenticationOptions()
            {
                LoginPath = new PathString("/Start/Login/"),
                AccessDeniedPath = new PathString("/Start/Forbidden/"),
                AutomaticChallenge = true
            });

            var supportedCultures = new[]
            {
                new CultureInfo("ru-RU"),
                new CultureInfo("en-US")
            };

            app.UseRequestLocalization(new RequestLocalizationOptions
            {
                DefaultRequestCulture = new RequestCulture(new CultureInfo("ru-RU"), new CultureInfo("ru-RU")),
                //DefaultRequestCulture = new RequestCulture(new CultureInfo("en-US"), new CultureInfo("en-US")),
                // Formatting numbers, dates, etc.
                SupportedCultures = supportedCultures,
                // UI strings that we have localized.
                SupportedUICultures = supportedCultures
            });

            // Add external authentication middleware below. To configure them please see http://go.microsoft.com/fwlink/?LinkID=532715

            app.UseMvc(routes =>
            {
                //routes.MapRoute("StartApp", "Start/{*.}", new { controller = "Start", action = "Index" });
                routes.MapRoute("SupplierApp_", "SupplierHome", new { controller = "SupplierHome", action = "Index" });
                routes.MapRoute("SupplierApp", "SupplierHome/{*.}", new { controller = "SupplierHome", action = "Index" });

                routes.MapRoute("InvestorApp", "InvestorHome/{*.}", new { controller = "InvestorHome", action = "Index" });
                routes.MapRoute("DebtorApp", "DebtorHome/{*.}", new { controller = "DebtorHome", action = "Index" });
                routes.MapRoute("AdminApp", "AdminHome/{*.}", new { controller = "AdminHome", action = "Index" });

                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });

            string date = DateTime.Now.ToString("yyyy-MM-dd");
            string format = "txt";
            string Debug = string.Format("Logs/{0}/{1}.log.{2}", date, LogEventLevel.Debug, format);
            string Information = string.Format("Logs/{0}/{1}.log.{2}", date, LogEventLevel.Information, format);
            string Warning = string.Format("Logs/{0}/{1}.log.{2}", date, LogEventLevel.Warning, format);
            string Error = string.Format("Logs/{0}/{1}.log.{2}", date, LogEventLevel.Error, format);
            string Fatal = string.Format("Logs/{0}/{1}.log.{2}", date, LogEventLevel.Fatal, format);

            Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Debug()
            .Enrich.FromLogContext()
            .WriteTo.RollingFile(Debug, LogEventLevel.Debug)
            .WriteTo.RollingFile(Information, LogEventLevel.Information)
            .WriteTo.RollingFile(Warning, LogEventLevel.Warning)
            .WriteTo.RollingFile(Error, LogEventLevel.Error)
            .WriteTo.RollingFile(Fatal, LogEventLevel.Fatal)
            .WriteTo.Seq("http://localhost:5341")
            .CreateLogger();
        }
    }
}
