﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using InvoiceCafe.Models;
using InvoiceCafe.Models.Domain;
using Microsoft.EntityFrameworkCore.Metadata;
using InvoiceCafe.Models.ViewModels.DomainViewModels;

namespace InvoiceCafe.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser, InvoiceCafeRole , Guid>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            //builder.Entity<Company>().HasMany<InvoiceCafeAspNetUser>().WithOne();


            //builder.Entity<Person>()
            //    .Property(f => f.Id)
            //    .ValueGeneratedOnAdd();

            builder.Entity<Person>().HasOne(u => u.ApplicationUser).
                WithOne(p => p.Person).HasForeignKey<ApplicationUser>(k => k.Id);

            builder.Entity<Company>()
                .HasOne(p => p.SignForm)
                .WithOne(i => i.Company)
                .HasForeignKey<SignForm>(b => b.Id);

            builder.Entity<DebtorSupplier>().HasKey(k => new { k.SupplierId, k.DebtorId });
            //builder.Entity<DebtorSupplier>().HasOne(d => d.Debtor).WithMany(ds => ds.DebtorSupplier).HasForeignKey(d => d.DebtorId);
            //builder.Entity<DebtorSupplier>().HasOne(d => d.Supplier).WithMany(ds => ds.DebtorSupplier).HasForeignKey(d => d.SupplierId);
            //builder.Entity<Company>().HasMany(i => i.Debtors).WithOne().HasForeignKey(i => i)

            base.OnModelCreating(builder);
        }

        public DbSet<RegisterFormViewModel> RegisterForms { get; set; }
        public DbSet<Person> Persons { get; set; }
        public DbSet<Company> Companies { get; set; }
        public DbSet<DebtorSupplier> DebtorsSuppliers { get; set; }
        public DbSet<Contract> Contracts { get; set; }
        public DbSet<ContractPersons> ContractPersons { get; set; }
        public DbSet<DZ> DZ { get; set; }
        public DbSet<Lot> Lots { get; set; }
        public DbSet<SignForm> SignForms { get; set; }
        public DbSet<Offer> Offers { get; set; }
        public DbSet<Deal> Deals { get; set; }
        public DbSet<EDSDocument> EDSDocuments { get; set; }
        public DbSet<FilterForLots> FiltersForLots { get; set; }
    }
}
