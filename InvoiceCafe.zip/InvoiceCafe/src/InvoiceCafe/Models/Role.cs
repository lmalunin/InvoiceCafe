﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using System;

namespace InvoiceCafe.Models
{
    public class InvoiceCafeRole : IdentityRole<Guid> { }
}