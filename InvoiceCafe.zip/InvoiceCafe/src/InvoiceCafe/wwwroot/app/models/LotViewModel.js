"use strict";
var LotViewModel = (function () {
    function LotViewModel() {
    }
    return LotViewModel;
}());
exports.LotViewModel = LotViewModel;
