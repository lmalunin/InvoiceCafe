"use strict";
var ContractViewModel = (function () {
    function ContractViewModel() {
    }
    return ContractViewModel;
}());
exports.ContractViewModel = ContractViewModel;
