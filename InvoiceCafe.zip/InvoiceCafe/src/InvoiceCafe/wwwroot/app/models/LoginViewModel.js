"use strict";
var LoginViewModel = (function () {
    function LoginViewModel() {
    }
    return LoginViewModel;
}());
exports.LoginViewModel = LoginViewModel;
