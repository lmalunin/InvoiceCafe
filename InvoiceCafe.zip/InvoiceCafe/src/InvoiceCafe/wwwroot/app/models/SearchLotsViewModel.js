"use strict";
var SearchLotsViewModel = (function () {
    function SearchLotsViewModel() {
    }
    return SearchLotsViewModel;
}());
exports.SearchLotsViewModel = SearchLotsViewModel;
