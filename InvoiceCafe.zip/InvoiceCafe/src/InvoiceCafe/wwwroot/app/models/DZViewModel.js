"use strict";
var DZViewModel = (function () {
    function DZViewModel() {
    }
    return DZViewModel;
}());
exports.DZViewModel = DZViewModel;
