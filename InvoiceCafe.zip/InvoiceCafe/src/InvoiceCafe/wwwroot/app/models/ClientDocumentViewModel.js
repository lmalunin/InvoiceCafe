"use strict";
var ClientDocumentViewModel = (function () {
    function ClientDocumentViewModel() {
    }
    return ClientDocumentViewModel;
}());
exports.ClientDocumentViewModel = ClientDocumentViewModel;
