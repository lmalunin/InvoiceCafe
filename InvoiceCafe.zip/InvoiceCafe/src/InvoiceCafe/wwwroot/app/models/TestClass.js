"use strict";
var TestClass = (function () {
    function TestClass() {
    }
    return TestClass;
}());
exports.TestClass = TestClass;
