"use strict";
var OfferViewModel = (function () {
    function OfferViewModel() {
    }
    return OfferViewModel;
}());
exports.OfferViewModel = OfferViewModel;
