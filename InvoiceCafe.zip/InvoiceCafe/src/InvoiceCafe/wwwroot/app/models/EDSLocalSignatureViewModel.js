"use strict";
var EDSLocalSignatureViewModel = (function () {
    function EDSLocalSignatureViewModel() {
    }
    return EDSLocalSignatureViewModel;
}());
exports.EDSLocalSignatureViewModel = EDSLocalSignatureViewModel;
