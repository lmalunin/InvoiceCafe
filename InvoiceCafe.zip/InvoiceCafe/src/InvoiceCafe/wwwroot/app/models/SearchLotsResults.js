"use strict";
var SearchLotsResults = (function () {
    function SearchLotsResults() {
    }
    return SearchLotsResults;
}());
exports.SearchLotsResults = SearchLotsResults;
