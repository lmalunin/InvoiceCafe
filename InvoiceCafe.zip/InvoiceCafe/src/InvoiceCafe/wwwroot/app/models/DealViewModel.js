"use strict";
var DealViewModel = (function () {
    function DealViewModel() {
    }
    return DealViewModel;
}());
exports.DealViewModel = DealViewModel;
