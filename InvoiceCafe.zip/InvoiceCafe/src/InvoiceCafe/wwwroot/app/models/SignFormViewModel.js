"use strict";
var SignFormViewModel = (function () {
    function SignFormViewModel() {
    }
    return SignFormViewModel;
}());
exports.SignFormViewModel = SignFormViewModel;
