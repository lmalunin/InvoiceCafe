"use strict";
var CompanyViewModel = (function () {
    function CompanyViewModel() {
    }
    return CompanyViewModel;
}());
exports.CompanyViewModel = CompanyViewModel;
