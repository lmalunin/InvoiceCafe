"use strict";
var DebtorViewModel = (function () {
    function DebtorViewModel() {
    }
    return DebtorViewModel;
}());
exports.DebtorViewModel = DebtorViewModel;
