"use strict";
var PersonViewModel = (function () {
    function PersonViewModel() {
    }
    return PersonViewModel;
}());
exports.PersonViewModel = PersonViewModel;
