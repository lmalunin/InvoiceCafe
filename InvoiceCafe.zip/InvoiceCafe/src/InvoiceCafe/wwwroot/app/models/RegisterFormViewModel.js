"use strict";
var RegisterFormViewModel = (function () {
    function RegisterFormViewModel() {
    }
    return RegisterFormViewModel;
}());
exports.RegisterFormViewModel = RegisterFormViewModel;
