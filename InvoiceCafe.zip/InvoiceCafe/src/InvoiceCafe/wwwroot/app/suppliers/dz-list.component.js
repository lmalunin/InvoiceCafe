"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var dataService_1 = require('./../dataService');
var storageService_1 = require('./../storageService');
require('./../rxjs-operators');
var DzListComponent = (function () {
    function DzListComponent(dataService, storService) {
        this.dataService = dataService;
        this.storService = storService;
        this.currentCompany = storService.getValue();
    }
    DzListComponent.prototype.ngOnInit = function () {
        this.getDebtors();
    };
    DzListComponent.prototype.getDebtors = function () {
        var _this = this;
        this.dataService.getDebtorsForSupplier(this.currentCompany.Id)
            .subscribe(function (debtors) { _this.debtors = debtors; }, function (errorObject) { return _this.process_error(errorObject); });
    };
    DzListComponent.prototype.process_error = function (errorObject) {
        for (var fieldName in errorObject)
            for (var message in errorObject[fieldName])
                this.errorMessages.push(errorObject[fieldName][message]);
        console.log(errorObject);
    };
    DzListComponent = __decorate([
        core_1.Component({
            selector: 'ic-dz-list',
            templateUrl: '/templates/v0102/suppliers/dz-list.tpl.html'
        }), 
        __metadata('design:paramtypes', [dataService_1.DataService, storageService_1.StorageService])
    ], DzListComponent);
    return DzListComponent;
}());
exports.DzListComponent = DzListComponent;
