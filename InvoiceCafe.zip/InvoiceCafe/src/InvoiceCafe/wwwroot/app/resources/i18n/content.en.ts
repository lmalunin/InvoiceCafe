export const TRANSLATION_EN = `
<?xml version="1.0" encoding="UTF-8" ?>
<xliff version="1.2" xmlns="urn:oasis:names:tc:xliff:document:1.2">
 <file source-language="en" datatype="plaintext" original="ng2.template">
   <body>
     <trans-unit id="20e0748d65f0fba8ef50ae9025639e6342a07954" datatype="html">
       <source>LaLa</source>
       <target>111</target>
     </trans-unit>


     <trans-unit id="ae89a08ab9c77434ca7b8b116498317ecac8f2d9" datatype="html">
       <source>WELCOME</source>
       <target>Welcome message 1!</target>
     </trans-unit>
     <trans-unit id="ecad2c91a275d1ef0b2c85f9cedc80fe2e62e976" datatype="html">
       <source>
        WELCOME
    </source>
       <target>Welcome message 2!</target>
     </trans-unit>
     <trans-unit id="ffb127c55a75e8245e9c68c5fd7487e489abb8a7" datatype="html">
       <source>LABEL_1 <x id="INTERPOLATION"/></source>
       <target>My value: '<x id="INTERPOLATION"/>'</target>
     </trans-unit>
   </body>
 </file>
</xliff>
`;